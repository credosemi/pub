#include "solaris.h"
#undef _SLASH_PROC_METHOD_
#undef NETSNMP_DONT_USE_NLIST

